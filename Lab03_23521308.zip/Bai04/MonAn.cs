﻿public class MonAn
{
    public int IDMA { get; set; }
    public string TenMonAn { get; set; }
    public string HinhAnh { get; set; }
    public string HoVaTenNguoiDongGop { get; set; }
}
