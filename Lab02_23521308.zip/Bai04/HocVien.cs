﻿using System;

namespace Lab02
{
    [Serializable]
    public class HocVien
    {
        public string Id { get; set; }
        public string Name { get; set; }

        public float Mon1 { get; set; }
        public float Mon2 { get; set; }
        public float Mon3 { get; set; }

        public float CalcAverage()
        {
            return (Mon1 + Mon2 + Mon3) / 3;
        }
    }
}
