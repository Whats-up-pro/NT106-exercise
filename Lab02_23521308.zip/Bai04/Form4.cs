﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace Lab02
{
    public partial class Bai04 : Form
    {
        public Bai04()
        {
            InitializeComponent();
        }

        private static string filePath = Path.Combine(
            Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName,
            "Bai04",
            "hocvien.txt"
        );

        private void btn_Save_Click(object sender, EventArgs e)
        {
            double mon1;
            bool mon1IsNumber = double.TryParse(txt_Mon1.Text, out mon1);

            double mon2;
            bool mon2IsNumber = double.TryParse(txt_Mon2.Text, out mon2);

            double mon3;
            bool mon3IsNumber = double.TryParse(txt_Mon3.Text, out mon3);

            if (string.IsNullOrWhiteSpace(txt_Id.Text))
            {
                MessageBox.Show("Bạn chưa nhập MSSV");
                txt_Id.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Name.Text))
            {
                MessageBox.Show("Bạn chưa nhập họ tên");
                txt_Name.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Mon1.Text))
            {
                MessageBox.Show("Bạn chưa nhập điểm môn 1");
                txt_Mon1.Focus();
                return;
            }
            else if (!mon1IsNumber || float.Parse(txt_Mon1.Text) < 0 || float.Parse(txt_Mon1.Text) > 10)
            {
                MessageBox.Show("Điểm môn 1 phải có giá trị từ 0 đến 10");
                txt_Mon1.Clear();
                txt_Mon1.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Mon2.Text))
            {
                MessageBox.Show("Bạn chưa nhập điểm môn 2");
                txt_Mon2.Focus();
                return;
            }
            else if (!mon2IsNumber || float.Parse(txt_Mon2.Text) < 0 || float.Parse(txt_Mon2.Text) > 10)
            {
                MessageBox.Show("Điểm môn 2 phải có giá trị từ 0 đến 10");
                txt_Mon2.Clear();
                txt_Mon2.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Mon3.Text))
            {
                MessageBox.Show("Bạn chưa nhập điểm môn 3");
                txt_Mon3.Focus();
                return;
            }
            else if (!mon3IsNumber || float.Parse(txt_Mon3.Text) < 0 || float.Parse(txt_Mon3.Text) > 10)
            {
                MessageBox.Show("Điểm môn 3 phải có giá trị từ 0 đến 10");
                txt_Mon3.Clear();
                txt_Mon3.Focus();
                return;
            }

            HocVien hv = new HocVien();
            hv.Id = txt_Id.Text;
            hv.Name = txt_Name.Text;

            hv.Mon1 = float.Parse(txt_Mon1.Text);
            hv.Mon2 = float.Parse(txt_Mon2.Text);
            hv.Mon3 = float.Parse(txt_Mon3.Text);

            FileStream fs = new FileStream(filePath, FileMode.Append);
            BinaryFormatter binaryFormatter = new BinaryFormatter();

            binaryFormatter.Serialize(fs, hv);
            fs.Close();
        }

        private void btn_Read_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.OK) return;

            FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate);
            BinaryFormatter binaryFormatter = new BinaryFormatter();

            dgv_Result.Rows.Clear();

            while (fs.Position != fs.Length)
            {
                int rowIndex = dgv_Result.Rows.Add();
                DataGridViewRow row = dgv_Result.Rows[rowIndex];
                HocVien hv = (HocVien)binaryFormatter.Deserialize(fs);

                row.Cells["Id"].Value = hv.Id;
                row.Cells["Full_Name"].Value = hv.Name;

                row.Cells["Mon1"].Value = hv.Mon1;
                row.Cells["Mon2"].Value = hv.Mon2;
                row.Cells["Mon3"].Value = hv.Mon3;
                row.Cells["Average"].Value = hv.CalcAverage();
            }
            fs.Close();
        }
    }
}
