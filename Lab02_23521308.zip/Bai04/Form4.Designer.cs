﻿namespace Lab02
{
    partial class Bai04
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Id = new System.Windows.Forms.TextBox();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Mon1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Mon3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Mon2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Read = new System.Windows.Forms.Button();
            this.dgv_Result = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Full_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mon1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mon2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mon3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Average = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "MSSV:";
            // 
            // txt_Id
            // 
            this.txt_Id.Location = new System.Drawing.Point(13, 30);
            this.txt_Id.Name = "txt_Id";
            this.txt_Id.Size = new System.Drawing.Size(92, 26);
            this.txt_Id.TabIndex = 1;
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(111, 30);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(100, 26);
            this.txt_Name.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Họ và tên:";
            // 
            // txt_Mon1
            // 
            this.txt_Mon1.Location = new System.Drawing.Point(13, 69);
            this.txt_Mon1.Name = "txt_Mon1";
            this.txt_Mon1.Size = new System.Drawing.Size(62, 26);
            this.txt_Mon1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Điểm môn 1:";
            // 
            // txt_Mon3
            // 
            this.txt_Mon3.Location = new System.Drawing.Point(149, 69);
            this.txt_Mon3.Name = "txt_Mon3";
            this.txt_Mon3.Size = new System.Drawing.Size(62, 26);
            this.txt_Mon3.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(149, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Điểm môn 3:";
            // 
            // txt_Mon2
            // 
            this.txt_Mon2.Location = new System.Drawing.Point(81, 69);
            this.txt_Mon2.Name = "txt_Mon2";
            this.txt_Mon2.Size = new System.Drawing.Size(62, 26);
            this.txt_Mon2.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(81, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Điểm môn 2:";
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(249, 28);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(143, 23);
            this.btn_Save.TabIndex = 10;
            this.btn_Save.Text = "Lưu thông tin học viên";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(117, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(249, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "DANH SÁCH HỌC VIÊN";
            // 
            // btn_Read
            // 
            this.btn_Read.Location = new System.Drawing.Point(249, 67);
            this.btn_Read.Name = "btn_Read";
            this.btn_Read.Size = new System.Drawing.Size(143, 23);
            this.btn_Read.TabIndex = 13;
            this.btn_Read.Text = "Hiển thị danh sách";
            this.btn_Read.UseVisualStyleBackColor = true;
            this.btn_Read.Click += new System.EventHandler(this.btn_Read_Click);
            // 
            // dgv_Result
            // 
            this.dgv_Result.AllowUserToAddRows = false;
            this.dgv_Result.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Full_Name,
            this.Mon1,
            this.Mon2,
            this.Mon3,
            this.Average});
            this.dgv_Result.Location = new System.Drawing.Point(12, 122);
            this.dgv_Result.Name = "dgv_Result";
            this.dgv_Result.RowHeadersVisible = false;
            this.dgv_Result.RowHeadersWidth = 62;
            this.dgv_Result.Size = new System.Drawing.Size(380, 177);
            this.dgv_Result.TabIndex = 14;
            // 
            // Id
            // 
            this.Id.HeaderText = "MSSV";
            this.Id.MinimumWidth = 8;
            this.Id.Name = "Id";
            // 
            // Full_Name
            // 
            this.Full_Name.HeaderText = "Họ và tên";
            this.Full_Name.MinimumWidth = 8;
            this.Full_Name.Name = "Full_Name";
            // 
            // Mon1
            // 
            this.Mon1.HeaderText = "Môn 1";
            this.Mon1.MinimumWidth = 8;
            this.Mon1.Name = "Mon1";
            // 
            // Mon2
            // 
            this.Mon2.HeaderText = "Môn 2";
            this.Mon2.MinimumWidth = 8;
            this.Mon2.Name = "Mon2";
            // 
            // Mon3
            // 
            this.Mon3.HeaderText = "Môn 3";
            this.Mon3.MinimumWidth = 8;
            this.Mon3.Name = "Mon3";
            // 
            // Average
            // 
            this.Average.HeaderText = "Trung bình";
            this.Average.MinimumWidth = 8;
            this.Average.Name = "Average";
            // 
            // Bai04
            // 
            this.ClientSize = new System.Drawing.Size(404, 311);
            this.Controls.Add(this.dgv_Result);
            this.Controls.Add(this.btn_Read);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.txt_Mon2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_Mon3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_Mon1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Id);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Bai04";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bai04";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Result)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Id;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Mon1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Mon3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Mon2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_Read;
        private System.Windows.Forms.DataGridView dgv_Result;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Full_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mon1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mon2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mon3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Average;
    }
}
